/*
*
* Author:			Karn Watcharasupat
* Class:			ECE6122
* Last Modified:	9/18/2024
*
* Description:		Header file direction enum
*
*/

#pragma once

enum Direction {
	UP, DOWN, LEFT, RIGHT
};